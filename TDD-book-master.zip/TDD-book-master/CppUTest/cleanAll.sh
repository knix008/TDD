#---
# Excerpted from "Test-Driven Development for Embedded C",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/jgade for more book information.
#---
#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v2.4a created on 2010-12-29-14-57"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
