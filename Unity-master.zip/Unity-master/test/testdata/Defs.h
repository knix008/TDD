#ifndef DEF_H
#define DEF_H

#define EXTERN_DECL

extern int CounterSuiteSetup;
extern int isArgumentOne(int i);

#endif
