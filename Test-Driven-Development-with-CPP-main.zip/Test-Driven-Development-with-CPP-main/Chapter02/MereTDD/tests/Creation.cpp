#include "../Test.h"

TEST("Test can be created")
{
}

TEST("Test with throw can be created")
{
    throw 1;
}
