#include "../Test.h"

#include <iostream>

int main ()
{
    return MereTDD::runTests(std::cout);
}
