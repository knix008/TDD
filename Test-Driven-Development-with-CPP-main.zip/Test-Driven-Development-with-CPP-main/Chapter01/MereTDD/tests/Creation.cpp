#include "../Test.h"

#include <iostream>

TEST
{
    std::cout << mName << std::endl;
}
