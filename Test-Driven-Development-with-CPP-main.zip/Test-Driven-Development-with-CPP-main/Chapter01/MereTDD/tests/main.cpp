#include "../Test.h"

int main ()
{
    MereTDD::runTests();

    return 0;
}
