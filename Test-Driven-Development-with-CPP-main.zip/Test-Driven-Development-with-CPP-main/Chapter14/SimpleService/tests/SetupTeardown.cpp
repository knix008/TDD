#include "SetupTeardown.h"

MereTDD::TestSuiteSetupAndTeardown<ServiceSetup>
gService1("Greeting Service", "Service 1");
