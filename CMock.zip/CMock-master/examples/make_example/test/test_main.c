#include "unity.h"
#include "mock_foo.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_main_should_initialize_foo(void)
{
    TEST_IGNORE_MESSAGE("TODO: Implement main!");
}
