#include "gmock/gmock.h"    
TEST(SoundexEncoding, RetainsSoleLetterOfOneLetterWord) { 
   Soundex soundex;   
}

