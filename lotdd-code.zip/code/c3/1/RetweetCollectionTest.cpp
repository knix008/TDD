#include "gmock/gmock.h"

TEST(ARetweetCollection, IsEmptyWhenCreated) {
   RetweetCollection retweets;

}
