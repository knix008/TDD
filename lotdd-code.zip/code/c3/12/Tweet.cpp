#include "Tweet.h"

const std::string Tweet::NULL_USER("@null");
